<?php
require_once "config/database.php";

$query = mysqli_query(
    $conn,
    "SELECT * FROM produk ORDER BY id DESC LIMIT 6"
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sweet Cake — Toko Kue</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php">
            <span class="brand-mark">♥</span>
            <span>Sweet Cake</span>
        </a>
        <div class="nav-links">
            <a href="index.php">Beranda</a>
            <a href="produk.php">Produk</a>
            <a href="tentang.php">Tentang Kami</a>
        </div>
    </div>
</nav>

<section class="hero">
    <div class="container hero-content">
        <span class="eyebrow">Sweet moments, sweet cakes</span>
        <h1>Kue manis untuk cerita yang lebih berkesan.</h1>
        <p>Temukan pilihan kue Sweet Cake yang cocok untuk menemani hari biasa maupun momen spesial bersama orang tersayang.</p>
        <a href="produk.php" class="btn">Jelajahi Produk →</a>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-head">
            <div>
                <h2>Produk Terbaru</h2>
                <p>Pilihan kue yang tersedia di Sweet Cake.</p>
            </div>
            <a class="btn btn-light" href="produk.php">Lihat Semua</a>
        </div>

        <div class="grid">
            <?php while ($row = mysqli_fetch_assoc($query)): ?>
                <article class="card product-card">
                    <?php if ($row['gambar']): ?>
                        <img class="product-image"
                             src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>"
                             alt="<?= htmlspecialchars($row['nama']); ?>">
                    <?php endif; ?>
                    <div class="product-card-body">
                        <span class="product-category"><?= htmlspecialchars($row['kategori']); ?></span>
                        <h3><?= htmlspecialchars($row['nama']); ?></h3>
                        <p class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></p>
                        <a class="btn btn-small" href="detail.php?id=<?= $row['id']; ?>">Lihat Detail</a>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<footer class="site-footer">
    <div class="container">Sweet Cake · Kue manis untuk momen istimewa ♡</div>
</footer>

</body>
</html>
