<?php
require_once "config/database.php";

$query = mysqli_query(
    $conn,
    "SELECT * FROM produk ORDER BY id DESC LIMIT 6"
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hearts to Hearts — Sweet Moments</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php">
            <span class="brand-mark">♥</span>
            <span>Hearts <i>to</i> Hearts</span>
        </a>

        <div class="nav-links">
            <a class="active" href="index.php">Beranda</a>
            <a href="produk.php">Koleksi</a>
            <a href="tentang.php">Tentang</a>
            <a href="auth/login.php" class="nav-admin">Admin <span>→</span></a>
        </div>
    </div>
</nav>

<section class="hero">
    <div class="hero-orbit orbit-one"></div>
    <div class="hero-orbit orbit-two"></div>
    <div class="hero-heart">♥</div>

    <div class="container hero-grid">
        <div class="hero-content">
            <span class="eyebrow">A LITTLE LOVE IN EVERY BITE</span>
            <h1>Small moments.<br><em>Big feelings.</em></h1>
            <p>
                Selamat datang di Hearts to Hearts, ruang kecil untuk menemukan
                pilihan kue manis yang dibuat untuk menemani cerita dan momen spesial.
            </p>

            <div class="hero-actions">
                <a href="produk.php" class="btn">Lihat Koleksi <span>→</span></a>
                <a href="tentang.php" class="text-link">Kenal lebih dekat ♡</a>
            </div>

            <div class="hero-trust">
                <div><strong>♡</strong><span>Dibuat dengan perhatian</span></div>
                <div><strong>✦</strong><span>Fresh & berkualitas</span></div>
            </div>
        </div>

        <div class="hero-card">
            <div class="hero-card-top">
                <span>HEARTS TO HEARTS</span>
                <span>♡</span>
            </div>
            <div class="hero-card-circle">
                <span>sweet</span>
                <strong>moments</strong>
                <small>taste better together</small>
            </div>
            <div class="hero-card-bottom">
                <span>Made for your special day</span>
                <span>♥</span>
            </div>
        </div>
    </div>
</section>

<section class="section section-soft">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="section-kicker">OUR FAVORITES</span>
                <h2>Something sweet for you.</h2>
                <p>Pilihan produk terbaru dari Hearts to Hearts.</p>
            </div>
            <a class="btn btn-light" href="produk.php">Lihat Semua <span>→</span></a>
        </div>

        <div class="grid">
            <?php while ($row = mysqli_fetch_assoc($query)): ?>
                <article class="card product-card">
                    <div class="product-image-wrap">
                        <?php if ($row['gambar']): ?>
                            <img class="product-image"
                                 src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>"
                                 alt="<?= htmlspecialchars($row['nama']); ?>">
                        <?php else: ?>
                            <div class="image-placeholder">♡</div>
                        <?php endif; ?>
                        <span class="floating-heart">♡</span>
                    </div>

                    <div class="product-card-body">
                        <span class="product-category"><?= htmlspecialchars($row['kategori']); ?></span>
                        <h3><?= htmlspecialchars($row['nama']); ?></h3>
                        <p class="product-desc"><?= htmlspecialchars($row['deskripsi']); ?></p>

                        <div class="product-bottom">
                            <p class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></p>
                            <a class="round-arrow" href="detail.php?id=<?= $row['id']; ?>">↗</a>
                        </div>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<section class="quote-section">
    <div class="container quote-box">
        <span class="quote-heart">♡</span>
        <p>“Because every little moment deserves a little sweetness.”</p>
        <span class="quote-line"></span>
        <small>HEARTS TO HEARTS</small>
    </div>
</section>

<footer class="site-footer">
    <div class="container">
        <span>Hearts to Hearts</span>
        <span>Made with love ♡</span>
    </div>
</footer>

</body>
</html>
