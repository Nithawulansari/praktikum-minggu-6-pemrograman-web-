# HEARTS TO HEARTS — CRUD PHP + MySQL

Project ini merupakan modifikasi dari project CRUD dasar dosen.
Konsep utama tetap dipertahankan: Login Admin, Logout, CRUD Produk,
upload gambar, pencarian/filter, pagination, dan database MySQL.

## 1. Teknologi
- PHP
- MySQL / MariaDB
- phpMyAdmin
- Laragon
- VS Code

## 2. Struktur folder

toko-kue/
├── admin/
│   ├── index.php
│   ├── produk.php
│   ├── tambah.php
│   ├── edit.php
│   ├── proses_produk.php
│   ├── hapus.php
│   └── logout.php
├── auth/
│   ├── login.php
│   ├── proses_login.php
│   └── buat_admin.php
├── config/
│   └── database.php
├── includes/
│   ├── auth.php
│   ├── flash.php
│   ├── header.php
│   └── footer.php
├── uploads/produk/
├── assets/style.css
├── index.php
├── produk.php
├── detail.php
├── tentang.php
└── toko_kue.sql

## 3. Cara menjalankan

1. Extract folder project ke:
   C:\laragon\www\

2. Pastikan nama folder:
   C:\laragon\www\toko-kue

3. Buka Laragon lalu klik Start All.

4. Buka:
   http://localhost/phpmyadmin

5. Buat database bernama:
   toko_kue

6. Pilih database toko_kue → Import → pilih file toko_kue.sql → Go.

7. Buka website:
   http://localhost/toko-kue/

8. Buka halaman admin:
   http://localhost/toko-kue/auth/login.php

## 4. Login Admin

Username:
admin

Password:
admin123

## 5. Alur sistem

Pengunjung:
Beranda → Koleksi Produk → Detail Produk

Admin:
Login → Dashboard → Produk → Tambah/Edit/Hapus → Logout

## 6. Bagian CRUD

CREATE:
admin/tambah.php → admin/proses_produk.php dengan aksi=tambah

READ:
admin/produk.php dan halaman publik produk.php

UPDATE:
admin/edit.php → admin/proses_produk.php dengan aksi=edit

DELETE:
admin/hapus.php

## 7. Catatan

Folder uploads/produk harus tetap ada karena digunakan untuk menyimpan
gambar produk.

Jika ingin mengganti nama toko, cukup ubah teks "Hearts to Hearts"
di file PHP yang menampilkannya. Struktur database tetap menggunakan
database `toko_kue` agar konsep dari materi dosen tidak berubah.
