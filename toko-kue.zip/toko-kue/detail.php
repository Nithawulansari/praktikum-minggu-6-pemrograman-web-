<?php
require_once "config/database.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$query = mysqli_query(
    $conn,
    "SELECT * FROM produk WHERE id = $id"
);

$produk = mysqli_fetch_assoc($query);

if (!$produk) {
    die("Produk tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($produk['nama']); ?> — Sweet Cake</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php">
            <span class="brand-mark">♥</span>
            <span>Sweet Cake</span>
        </a>
        <div class="nav-links">
            <a href="index.php">Beranda</a>
            <a href="produk.php">Produk</a>
            <a href="tentang.php">Tentang Kami</a>
        </div>
    </div>
</nav>

<main class="section">
    <div class="container">
        <div class="detail-layout">
            <div>
                <?php if ($produk['gambar']): ?>
                    <img class="detail-image"
                         src="uploads/produk/<?= htmlspecialchars($produk['gambar']); ?>"
                         alt="<?= htmlspecialchars($produk['nama']); ?>">
                <?php endif; ?>
            </div>

            <article class="card">
                <span class="product-category"><?= htmlspecialchars($produk['kategori']); ?></span>
                <h1 class="page-title"><?= htmlspecialchars($produk['nama']); ?></h1>
                <p class="product-desc">
                    <?= nl2br(htmlspecialchars($produk['deskripsi'])); ?>
                </p>

                <div class="info-list">
                    <div class="info-box">
                        <small>Harga</small>
                        <strong>Rp <?= number_format($produk['harga'],0,',','.'); ?></strong>
                    </div>
                    <div class="info-box">
                        <small>Stok tersedia</small>
                        <strong><?= $produk['stok']; ?> pcs</strong>
                    </div>
                </div>

                <a href="produk.php" class="btn btn-light">← Kembali ke Produk</a>
            </article>
        </div>
    </div>
</main>

<footer class="site-footer">
    <div class="container">Sweet Cake · Kue manis untuk momen istimewa ♡</div>
</footer>

</body>
</html>
