<?php
require_once "config/database.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$produk = mysqli_fetch_assoc($query);

if (!$produk) {
    http_response_code(404);
    die("Produk tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($produk['nama']); ?> — Hearts to Hearts</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php"><span class="brand-mark">♥</span><span>Hearts <i>to</i> Hearts</span></a>
        <div class="nav-links">
            <a href="index.php">Beranda</a>
            <a href="produk.php">Koleksi</a>
            <a href="tentang.php">Tentang</a>
            <a href="auth/login.php" class="nav-admin">Admin <span>→</span></a>
        </div>
    </div>
</nav>

<main class="section">
    <div class="container">
        <a href="produk.php" class="back-link">← Kembali ke koleksi</a>

        <div class="detail-layout">
            <div class="detail-image-box">
                <?php if ($produk['gambar']): ?>
                    <img class="detail-image"
                         src="uploads/produk/<?= htmlspecialchars($produk['gambar']); ?>"
                         alt="<?= htmlspecialchars($produk['nama']); ?>">
                <?php else: ?>
                    <div class="detail-placeholder">♡</div>
                <?php endif; ?>
            </div>

            <article class="detail-content">
                <span class="product-category"><?= htmlspecialchars($produk['kategori']); ?></span>
                <h1 class="page-title"><?= htmlspecialchars($produk['nama']); ?></h1>
                <p class="detail-desc"><?= nl2br(htmlspecialchars($produk['deskripsi'])); ?></p>

                <div class="detail-price">
                    <small>Harga</small>
                    <strong>Rp <?= number_format($produk['harga'],0,',','.'); ?></strong>
                </div>

                <div class="info-list">
                    <div class="info-box">
                        <small>Stok tersedia</small>
                        <strong><?= $produk['stok']; ?> pcs</strong>
                    </div>
                    <div class="info-box">
                        <small>Kategori</small>
                        <strong><?= htmlspecialchars($produk['kategori']); ?></strong>
                    </div>
                </div>

                <div class="detail-note">♡ Dipersiapkan dengan perhatian untuk momen spesialmu.</div>
            </article>
        </div>
    </div>
</main>

<footer class="site-footer">
    <div class="container"><span>Hearts to Hearts</span><span>Made with love ♡</span></div>
</footer>

</body>
</html>
