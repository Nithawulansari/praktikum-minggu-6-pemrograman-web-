<?php
session_start();

if (isset($_SESSION['admin_id'])) {
    header("Location: ../admin/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin — Sweet Cake</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="login-page">
    <div class="login-box">
        <div class="login-logo">
            <div class="brand-mark">♥</div>
            <h1>Sweet Cake</h1>
            <p class="muted">Panel administrasi</p>
        </div>

        <div class="card">
            <h2 style="margin-top:0;">Selamat datang kembali</h2>
            <p class="muted">Masuk untuk mengelola katalog produk.</p>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert">
                    <?= htmlspecialchars($_SESSION['error']); ?>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <form action="proses_login.php" method="POST">
                <label for="username">Username</label>
                <input id="username" type="text" name="username" required>

                <label for="password">Password</label>
                <input id="password" type="password" name="password" required>

                <button type="submit" class="btn" style="width:100%;">Masuk ke Dashboard</button>
            </form>

            <a href="../index.php" style="display:block;margin-top:18px;color:var(--pink-700);text-decoration:none;font-weight:600;">
                ← Kembali ke website
            </a>
        </div>
    </div>
</div>
</body>
</html>
