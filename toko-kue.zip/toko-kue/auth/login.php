<?php
session_start();

if (isset($_SESSION['admin_id'])) {
    header("Location: ../admin/index.php");
    exit;
}

$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk — Hearts to Hearts</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body class="login-body">
<div class="login-page">
    <div class="login-decoration decoration-one">♥</div>
    <div class="login-decoration decoration-two">♡</div>

    <div class="login-box">
        <div class="login-brand">
            <div class="brand-mark brand-mark-lg">♥</div>
            <span class="eyebrow">HEARTS TO HEARTS</span>
            <h1>Welcome back.</h1>
            <p>Masuk ke ruang pengelolaan toko dan kelola produk dengan mudah.</p>
        </div>

        <div class="login-card">
            <?php if ($error): ?>
                <div class="alert alert-error">♥ <?= htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form action="proses_login.php" method="POST" autocomplete="off">
                <div class="input-group">
                    <label for="username">Username</label>
                    <div class="input-icon">
                        <span>♡</span>
                        <input id="username" type="text" name="username"
                               placeholder="Masukkan username" required autofocus>
                    </div>
                </div>

                <div class="input-group">
                    <label for="password">Password</label>
                    <div class="input-icon">
                        <span>♡</span>
                        <input id="password" type="password" name="password"
                               placeholder="Masukkan password" required>
                        <button type="button" class="password-toggle" onclick="togglePassword()">Lihat</button>
                    </div>
                </div>

                <button type="submit" class="btn login-btn">
                    Masuk ke Dashboard <span>→</span>
                </button>
            </form>

            <div class="login-divider"><span>HEARTS TO HEARTS</span></div>

            <a href="../index.php" class="back-link">← Kembali ke website</a>
        </div>

        <p class="login-note">Admin area · Kelola katalog dengan sepenuh hati ♡</p>
    </div>
</div>

<script>
function togglePassword() {
    const password = document.getElementById('password');
    const button = document.querySelector('.password-toggle');

    if (password.type === 'password') {
        password.type = 'text';
        button.textContent = 'Sembunyikan';
    } else {
        password.type = 'password';
        button.textContent = 'Lihat';
    }
}
</script>
</body>
</html>
