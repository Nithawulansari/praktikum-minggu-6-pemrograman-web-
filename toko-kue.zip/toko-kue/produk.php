<?php
require_once "config/database.php";

$keyword = $_GET['keyword'] ?? '';

if ($keyword != '') {
    $keyword_safe = mysqli_real_escape_string($conn, $keyword);
    $query = mysqli_query(
        $conn,
        "SELECT * FROM produk
         WHERE nama LIKE '%$keyword_safe%'
         ORDER BY id DESC"
    );
} else {
    $query = mysqli_query(
        $conn,
        "SELECT * FROM produk ORDER BY id DESC"
    );
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk — Sweet Cake</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php">
            <span class="brand-mark">♥</span>
            <span>Sweet Cake</span>
        </a>
        <div class="nav-links">
            <a href="index.php">Beranda</a>
            <a href="produk.php">Produk</a>
            <a href="tentang.php">Tentang Kami</a>
        </div>
    </div>
</nav>

<main class="section">
    <div class="container">
        <div class="section-head">
            <div>
                <h1 class="page-title">Koleksi Produk</h1>
                <p>Pilih kue favoritmu dari katalog Sweet Cake.</p>
            </div>
        </div>

        <div class="card">
            <form method="GET" class="search-row">
                <input type="text" name="keyword"
                       placeholder="Cari nama produk..."
                       value="<?= htmlspecialchars($keyword); ?>">
                <button type="submit" class="btn">Cari Produk</button>
            </form>
        </div>

        <div class="grid">
            <?php while ($row = mysqli_fetch_assoc($query)): ?>
                <article class="card product-card">
                    <?php if ($row['gambar']): ?>
                        <img class="product-image"
                             src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>"
                             alt="<?= htmlspecialchars($row['nama']); ?>">
                    <?php endif; ?>
                    <div class="product-card-body">
                        <span class="product-category"><?= htmlspecialchars($row['kategori']); ?></span>
                        <h3><?= htmlspecialchars($row['nama']); ?></h3>
                        <p class="product-desc"><?= htmlspecialchars($row['deskripsi']); ?></p>
                        <p class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></p>
                        <a href="detail.php?id=<?= $row['id']; ?>" class="btn btn-small">Lihat Detail</a>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>
    </div>
</main>

<footer class="site-footer">
    <div class="container">Sweet Cake · Kue manis untuk momen istimewa ♡</div>
</footer>

</body>
</html>
