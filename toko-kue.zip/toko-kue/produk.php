<?php
require_once "config/database.php";

$keyword = trim($_GET['keyword'] ?? '');

if ($keyword !== '') {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT * FROM produk
         WHERE nama LIKE ? OR kategori LIKE ?
         ORDER BY id DESC"
    );
    $search = "%$keyword%";
    mysqli_stmt_bind_param($stmt, "ss", $search, $search);
    mysqli_stmt_execute($stmt);
    $query = mysqli_stmt_get_result($stmt);
} else {
    $query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koleksi — Hearts to Hearts</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php"><span class="brand-mark">♥</span><span>Hearts <i>to</i> Hearts</span></a>
        <div class="nav-links">
            <a href="index.php">Beranda</a>
            <a class="active" href="produk.php">Koleksi</a>
            <a href="tentang.php">Tentang</a>
            <a href="auth/login.php" class="nav-admin">Admin <span>→</span></a>
        </div>
    </div>
</nav>

<main class="section">
    <div class="container">
        <div class="page-hero">
            <span class="eyebrow">OUR COLLECTION</span>
            <h1 class="page-title">Made with love,<br><em>chosen by you.</em></h1>
            <p>Temukan koleksi kue yang cocok untuk hadiah, perayaan, atau sekadar membuat hari terasa lebih manis.</p>
        </div>

        <div class="search-card">
            <form method="GET" class="search-row">
                <div class="search-input">
                    <span>⌕</span>
                    <input type="text" name="keyword"
                           placeholder="Cari nama atau kategori..."
                           value="<?= htmlspecialchars($keyword); ?>">
                </div>
                <button type="submit" class="btn">Cari <span>→</span></button>
                <?php if ($keyword !== ''): ?>
                    <a href="produk.php" class="btn btn-light">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <?php if (mysqli_num_rows($query) === 0): ?>
            <div class="empty-state card">
                <div class="empty-icon">♡</div>
                <h3>Produk tidak ditemukan</h3>
                <p>Coba gunakan kata kunci yang berbeda.</p>
            </div>
        <?php else: ?>
            <div class="grid">
                <?php while ($row = mysqli_fetch_assoc($query)): ?>
                    <article class="card product-card">
                        <div class="product-image-wrap">
                            <?php if ($row['gambar']): ?>
                                <img class="product-image"
                                     src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>"
                                     alt="<?= htmlspecialchars($row['nama']); ?>">
                            <?php else: ?>
                                <div class="image-placeholder">♡</div>
                            <?php endif; ?>
                            <span class="floating-heart">♡</span>
                        </div>

                        <div class="product-card-body">
                            <span class="product-category"><?= htmlspecialchars($row['kategori']); ?></span>
                            <h3><?= htmlspecialchars($row['nama']); ?></h3>
                            <p class="product-desc"><?= htmlspecialchars($row['deskripsi']); ?></p>
                            <div class="product-bottom">
                                <p class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></p>
                                <a class="round-arrow" href="detail.php?id=<?= $row['id']; ?>">↗</a>
                            </div>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<footer class="site-footer">
    <div class="container"><span>Hearts to Hearts</span><span>Made with love ♡</span></div>
</footer>

</body>
</html>
