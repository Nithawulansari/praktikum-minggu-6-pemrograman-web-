<?php
require_once "../includes/auth.php";
require_once "../config/database.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    die("Produk tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk — Hearts to Hearts</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-side">
        <div class="admin-brand"><div class="admin-logo">♥</div><div><strong>Hearts to Hearts</strong><span>Admin Studio</span></div></div>
        <div class="admin-label">MENU UTAMA</div>
        <nav class="admin-menu">
            <a href="index.php"><span>⌂</span> Dashboard</a>
            <a class="active" href="produk.php"><span>▣</span> Produk</a>
            <a href="../index.php"><span>↗</span> Lihat Website</a>
        </nav>
        <div class="sidebar-bottom"><div class="admin-mini-card"><span class="mini-heart">♥</span><div><small>Signed in as</small><strong><?= htmlspecialchars($_SESSION['admin_nama']); ?></strong></div></div><a href="logout.php" class="logout-link">↪ Keluar dari akun</a></div>
    </aside>

    <main class="admin-content">
        <div class="admin-inner narrow-admin">
            <header class="admin-top">
                <div><a href="produk.php" class="back-link">← Kembali ke produk</a><h1 class="form-page-title">Edit Produk</h1><p class="muted">Perbarui informasi produk yang dipilih.</p></div>
            </header>

            <?php require "../includes/flash.php"; ?>

            <div class="card form-card">
                <div class="form-card-heading"><span class="form-icon">✦</span><div><h2><?= htmlspecialchars($data['nama']); ?></h2><p>Ubah data yang diperlukan, lalu simpan perubahan.</p></div></div>

                <form action="proses_produk.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="aksi" value="edit">
                    <input type="hidden" name="id" value="<?= $data['id']; ?>">

                    <div class="form-grid">
                        <div><label>Nama Produk</label><input type="text" name="nama" value="<?= htmlspecialchars($data['nama']); ?>" required></div>
                        <div>
                            <label>Kategori</label>
                            <select name="kategori" required>
                                <option value="">Pilih kategori</option>
                                <?php foreach (['Cake','Brownies','Donat'] as $kat): ?>
                                    <option value="<?= $kat; ?>" <?= $data['kategori'] === $kat ? 'selected' : ''; ?>><?= $kat; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-full"><label>Deskripsi</label><textarea name="deskripsi" rows="5" required><?= htmlspecialchars($data['deskripsi']); ?></textarea></div>
                        <div><label>Harga</label><input type="number" name="harga" min="0" value="<?= $data['harga']; ?>" required></div>
                        <div><label>Stok</label><input type="number" name="stok" min="0" value="<?= $data['stok']; ?>" required></div>
                        <div class="form-full">
                            <label>Ganti Gambar <small>(opsional, maksimal 2 MB)</small></label>
                            <?php if ($data['gambar']): ?><img class="preview-image" src="../uploads/produk/<?= htmlspecialchars($data['gambar']); ?>" alt=""><br><br><?php endif; ?>
                            <input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
                        </div>
                    </div>

                    <div class="form-actions"><button type="submit" class="btn">Simpan Perubahan ♡</button><a href="produk.php" class="btn btn-light">Batal</a></div>
                </form>
            </div>
        </div>
    </main>
</div>
</body>
</html>
