<?php
session_start();
require_once "../includes/auth.php";
require_once "../config/database.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$produk = mysqli_fetch_assoc($query);

if (!$produk) {
    die("Produk tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk — Sweet Cake</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="admin-shell">
<aside class="admin-side">
    <div class="admin-brand">
        <strong>Sweet Cake</strong>
        <span>Admin Panel</span>
    </div>
    <nav class="admin-menu">
        <a class="" href="index.php">⌂ Dashboard</a>
        <a class="active" href="produk.php">▣ Produk</a>
        <a href="../index.php">↗ Website</a>
        <a href="logout.php">↪ Logout</a>
    </nav>
</aside>
    <main class="admin-content">
        <div class="admin-inner">
            <div class="admin-top">
                <div>
                    <h1>Edit Produk</h1>
                    <p class="muted">Perbarui informasi produk yang dipilih.</p>
                </div>
            </div>

            <?php include "../includes/flash.php"; ?>

            <div class="card">
                <form action="proses_produk.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="aksi" value="edit">
                    <input type="hidden" name="id" value="<?= $produk['id']; ?>">

                    <div class="form-grid">
                        <div>
                            <label>Nama Produk</label>
                            <input type="text" name="nama" value="<?= htmlspecialchars($produk['nama']); ?>" required>
                        </div>
                        <div>
                            <label>Kategori</label>
                            <select name="kategori" required>
                                <option value="Cake" <?= $produk['kategori'] == 'Cake' ? 'selected' : ''; ?>>Cake</option>
                                <option value="Brownies" <?= $produk['kategori'] == 'Brownies' ? 'selected' : ''; ?>>Brownies</option>
                                <option value="Donat" <?= $produk['kategori'] == 'Donat' ? 'selected' : ''; ?>>Donat</option>
                            </select>
                        </div>
                        <div class="form-full">
                            <label>Deskripsi</label>
                            <textarea name="deskripsi" rows="5" required><?= htmlspecialchars($produk['deskripsi']); ?></textarea>
                        </div>
                        <div>
                            <label>Harga</label>
                            <input type="number" name="harga" value="<?= $produk['harga']; ?>" min="0" required>
                        </div>
                        <div>
                            <label>Stok</label>
                            <input type="number" name="stok" value="<?= $produk['stok']; ?>" min="0" required>
                        </div>
                        <div class="form-full">
                            <label>Ganti Gambar</label>
                            <input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
                            <?php if ($produk['gambar']): ?>
                                <p class="muted">Gambar saat ini:</p>
                                <img class="preview-image"
                                     src="../uploads/produk/<?= htmlspecialchars($produk['gambar']); ?>"
                                     alt="<?= htmlspecialchars($produk['nama']); ?>">
                            <?php endif; ?>
                        </div>
                    </div>

                    <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:20px;">
                        <button type="submit" class="btn">Simpan Perubahan</button>
                        <a href="produk.php" class="btn btn-light">Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </main>
</div>
</body>
</html>
