<?php
require_once "../includes/auth.php";
require_once "../config/database.php";

$total_produk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM produk"))['total'];
$total_kategori = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT kategori) AS total FROM produk"))['total'];
$total_stok = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(stok),0) AS total FROM produk"))['total'];
$produk_terbaru = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Hearts to Hearts</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-side">
        <div class="admin-brand">
            <div class="admin-logo">♥</div>
            <div><strong>Hearts to Hearts</strong><span>Admin Studio</span></div>
        </div>

        <div class="admin-label">MENU UTAMA</div>
        <nav class="admin-menu">
            <a class="active" href="index.php"><span>⌂</span> Dashboard</a>
            <a href="produk.php"><span>▣</span> Produk</a>
            <a href="../index.php"><span>↗</span> Lihat Website</a>
        </nav>

        <div class="sidebar-bottom">
            <div class="admin-mini-card">
                <span class="mini-heart">♥</span>
                <div><small>Signed in as</small><strong><?= htmlspecialchars($_SESSION['admin_nama']); ?></strong></div>
            </div>
            <a href="logout.php" class="logout-link">↪ Keluar dari akun</a>
        </div>
    </aside>

    <main class="admin-content">
        <div class="admin-inner">
            <header class="admin-top">
                <div>
                    <span class="section-kicker">ADMIN STUDIO</span>
                    <h1>Good day, <?= htmlspecialchars($_SESSION['admin_nama']); ?>. ♡</h1>
                    <p class="muted">Kelola katalog Hearts to Hearts dari satu tempat.</p>
                </div>
                <a href="tambah.php" class="btn">+ Tambah Produk</a>
            </header>

            <?php require "../includes/flash.php"; ?>

            <div class="stats">
                <div class="stat-card stat-pink">
                    <div class="stat-icon">♡</div>
                    <span>Total Produk</span>
                    <strong><?= $total_produk; ?></strong>
                    <small>produk dalam katalog</small>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">✦</div>
                    <span>Total Kategori</span>
                    <strong><?= $total_kategori; ?></strong>
                    <small>kategori tersedia</small>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">⌁</div>
                    <span>Total Stok</span>
                    <strong><?= $total_stok; ?></strong>
                    <small>pcs tersedia</small>
                </div>
            </div>

            <div class="dashboard-grid">
                <section class="card admin-table-card">
                    <div class="card-heading">
                        <div><span class="section-kicker">LATEST</span><h2>Produk Terbaru</h2></div>
                        <a href="produk.php" class="text-link">Lihat semua →</a>
                    </div>

                    <div class="table-wrap">
                        <table>
                            <thead><tr><th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th></tr></thead>
                            <tbody>
                            <?php while ($row = mysqli_fetch_assoc($produk_terbaru)): ?>
                                <tr>
                                    <td>
                                        <div class="table-product">
                                            <?php if ($row['gambar']): ?>
                                                <img src="../uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" alt="">
                                            <?php else: ?>
                                                <span class="table-heart">♡</span>
                                            <?php endif; ?>
                                            <strong><?= htmlspecialchars($row['nama']); ?></strong>
                                        </div>
                                    </td>
                                    <td><span class="category-pill"><?= htmlspecialchars($row['kategori']); ?></span></td>
                                    <td>Rp <?= number_format($row['harga'],0,',','.'); ?></td>
                                    <td><?= $row['stok']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </section>

                <aside class="welcome-card">
                    <div class="welcome-glow">♥</div>
                    <span class="section-kicker">HEARTS TO HEARTS</span>
                    <h2>Everything starts<br>with a little care.</h2>
                    <p>Gunakan menu Produk untuk menambah, mengedit, mencari, atau menghapus data katalog.</p>
                    <a href="produk.php" class="btn btn-white">Kelola Produk →</a>
                </aside>
            </div>
        </div>
    </main>
</div>
</body>
</html>
