<?php
require_once "../includes/auth.php";
require_once "../config/database.php";

$total_produk = mysqli_query($conn, "SELECT COUNT(*) AS total FROM produk");
$data_produk = mysqli_fetch_assoc($total_produk);

$total_kategori = mysqli_query($conn, "SELECT COUNT(DISTINCT kategori) AS total FROM produk");
$data_kategori = mysqli_fetch_assoc($total_kategori);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Sweet Cake</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="admin-shell">
<aside class="admin-side">
    <div class="admin-brand">
        <strong>Sweet Cake</strong>
        <span>Admin Panel</span>
    </div>
    <nav class="admin-menu">
        <a class="active" href="index.php">⌂ Dashboard</a>
        <a class="" href="produk.php">▣ Produk</a>
        <a href="../index.php">↗ Website</a>
        <a href="logout.php">↪ Logout</a>
    </nav>
</aside>
    <main class="admin-content">
        <div class="admin-inner">
            <div class="admin-top">
                <div>
                    <h1>Dashboard</h1>
                    <p class="muted">Ringkasan toko Sweet Cake.</p>
                </div>
                <span class="eyebrow">Administrator</span>
            </div>

            <div class="card">
                <p style="margin:0;color:var(--muted);">Selamat datang,</p>
                <h2 style="margin:5px 0 0;"><?= htmlspecialchars($_SESSION['admin_nama']); ?> 👋</h2>
            </div>

            <div class="stats">
                <div class="stat-card">
                    <span>Total Produk</span>
                    <strong><?= $data_produk['total']; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Total Kategori</span>
                    <strong><?= $data_kategori['total']; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Status Sistem</span>
                    <strong style="font-size:1.45rem;">Aktif</strong>
                </div>
            </div>

            <div class="card">
                <span class="product-category">Manajemen katalog</span>
                <h2 style="margin:4px 0 8px;">Kelola Produk</h2>
                <p class="muted">Tambah, edit, cari, filter, atau hapus produk dari katalog toko.</p>
                <a href="produk.php" class="btn">Buka Manajemen Produk</a>
            </div>
        </div>
    </main>
</div>
</body>
</html>
