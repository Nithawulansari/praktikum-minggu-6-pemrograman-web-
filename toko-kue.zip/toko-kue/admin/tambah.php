<?php
require_once "../includes/auth.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk — Hearts to Hearts</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-side">
        <div class="admin-brand"><div class="admin-logo">♥</div><div><strong>Hearts to Hearts</strong><span>Admin Studio</span></div></div>
        <div class="admin-label">MENU UTAMA</div>
        <nav class="admin-menu">
            <a href="index.php"><span>⌂</span> Dashboard</a>
            <a class="active" href="produk.php"><span>▣</span> Produk</a>
            <a href="../index.php"><span>↗</span> Lihat Website</a>
        </nav>
        <div class="sidebar-bottom"><div class="admin-mini-card"><span class="mini-heart">♥</span><div><small>Signed in as</small><strong><?= htmlspecialchars($_SESSION['admin_nama']); ?></strong></div></div><a href="logout.php" class="logout-link">↪ Keluar dari akun</a></div>
    </aside>

    <main class="admin-content">
        <div class="admin-inner narrow-admin">
            <header class="admin-top">
                <div><a href="produk.php" class="back-link">← Kembali ke produk</a><h1 class="form-page-title">Tambah Produk</h1><p class="muted">Tambahkan produk baru ke katalog Hearts to Hearts.</p></div>
            </header>

            <?php require "../includes/flash.php"; ?>

            <div class="card form-card">
                <div class="form-card-heading"><span class="form-icon">♡</span><div><h2>Informasi Produk</h2><p>Lengkapi data di bawah ini dengan benar.</p></div></div>

                <form action="proses_produk.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="aksi" value="tambah">

                    <div class="form-grid">
                        <div>
                            <label>Nama Produk</label>
                            <input type="text" name="nama" placeholder="Contoh: Brownies Coklat" required>
                        </div>
                        <div>
                            <label>Kategori</label>
                            <select name="kategori" required>
                                <option value="">Pilih kategori</option>
                                <option value="Cake">Cake</option>
                                <option value="Brownies">Brownies</option>
                                <option value="Donat">Donat</option>
                            </select>
                        </div>
                        <div class="form-full">
                            <label>Deskripsi</label>
                            <textarea name="deskripsi" rows="5" placeholder="Tuliskan deskripsi singkat produk..." required></textarea>
                        </div>
                        <div>
                            <label>Harga</label>
                            <input type="number" name="harga" min="0" placeholder="45000" required>
                        </div>
                        <div>
                            <label>Stok</label>
                            <input type="number" name="stok" min="0" placeholder="20" required>
                        </div>
                        <div class="form-full">
                            <label>Gambar Produk <small>(opsional, maksimal 2 MB)</small></label>
                            <input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
                        </div>
                    </div>

                    <div class="form-actions"><button type="submit" class="btn">Simpan Produk ♡</button><a href="produk.php" class="btn btn-light">Batal</a></div>
                </form>
            </div>
        </div>
    </main>
</div>
</body>
</html>
