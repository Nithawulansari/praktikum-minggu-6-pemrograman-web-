<?php
session_start();
require_once "../includes/auth.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk — Sweet Cake</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="admin-shell">
<aside class="admin-side">
    <div class="admin-brand">
        <strong>Sweet Cake</strong>
        <span>Admin Panel</span>
    </div>
    <nav class="admin-menu">
        <a class="" href="index.php">⌂ Dashboard</a>
        <a class="active" href="produk.php">▣ Produk</a>
        <a href="../index.php">↗ Website</a>
        <a href="logout.php">↪ Logout</a>
    </nav>
</aside>
    <main class="admin-content">
        <div class="admin-inner">
            <div class="admin-top">
                <div>
                    <h1>Tambah Produk</h1>
                    <p class="muted">Masukkan produk baru ke katalog.</p>
                </div>
            </div>

            <div class="card">
                <form action="proses_produk.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="aksi" value="tambah">

                    <div class="form-grid">
                        <div>
                            <label>Nama Produk</label>
                            <input type="text" name="nama" required>
                        </div>
                        <div>
                            <label>Kategori</label>
                            <select name="kategori" required>
                                <option value="">Pilih kategori</option>
                                <option value="Cake">Cake</option>
                                <option value="Brownies">Brownies</option>
                                <option value="Donat">Donat</option>
                            </select>
                        </div>
                        <div class="form-full">
                            <label>Deskripsi</label>
                            <textarea name="deskripsi" rows="5" required></textarea>
                        </div>
                        <div>
                            <label>Harga</label>
                            <input type="number" name="harga" min="0" required>
                        </div>
                        <div>
                            <label>Stok</label>
                            <input type="number" name="stok" min="0" required>
                        </div>
                        <div class="form-full">
                            <label>Gambar Produk</label>
                            <input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
                        </div>
                    </div>

                    <div style="display:flex;gap:9px;flex-wrap:wrap;">
                        <button type="submit" class="btn">Simpan Produk</button>
                        <a href="produk.php" class="btn btn-light">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </main>
</div>
</body>
</html>
