<?php
require_once "../includes/auth.php";
require_once "../config/database.php";

$aksi = $_POST['aksi'] ?? '';

function kembali($url, $type, $message) {
    $_SESSION[$type] = $message;
    header("Location: $url");
    exit;
}

function uploadGambar($field, $folder) {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    $file = $_FILES[$field];
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'webp'];

    if (!in_array($extension, $allowed, true) || $file['size'] > 2 * 1024 * 1024) {
        return false;
    }

    $nama = uniqid("product_", true) . "." . $extension;

    if (!move_uploaded_file($file['tmp_name'], $folder . $nama)) {
        return false;
    }

    return $nama;
}

/* =========================
   TAMBAH PRODUK
========================= */
if ($aksi === 'tambah') {
    $nama = trim($_POST['nama'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga = $_POST['harga'] ?? '';
    $stok = $_POST['stok'] ?? '';

    if ($nama === '' || $kategori === '' || $deskripsi === '' || $harga === '' || $stok === '') {
        kembali("tambah.php", "error", "Semua data wajib diisi.");
    }

    if (!is_numeric($harga) || $harga < 0) {
        kembali("tambah.php", "error", "Harga harus berupa angka yang valid.");
    }

    if (!is_numeric($stok) || $stok < 0) {
        kembali("tambah.php", "error", "Stok harus berupa angka yang valid.");
    }

    $gambar = uploadGambar('gambar', '../uploads/produk/');

    if ($gambar === false) {
        kembali("tambah.php", "error", "Gambar harus JPG, JPEG, PNG, atau WEBP dan maksimal 2 MB.");
    }

    $harga = (float)$harga;
    $stok = (int)$stok;

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO produk (nama, kategori, deskripsi, harga, stok, gambar)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "sssdis", $nama, $kategori, $deskripsi, $harga, $stok, $gambar);

    if (mysqli_stmt_execute($stmt)) {
        kembali("produk.php", "success", "Produk berhasil ditambahkan.");
    }

    kembali("tambah.php", "error", "Produk gagal ditambahkan.");
}

/* =========================
   EDIT PRODUK
========================= */
if ($aksi === 'edit') {
    $id = (int)($_POST['id'] ?? 0);
    $nama = trim($_POST['nama'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga = $_POST['harga'] ?? '';
    $stok = $_POST['stok'] ?? '';

    if ($id <= 0 || $nama === '' || $kategori === '' || $deskripsi === '' || $harga === '' || $stok === '') {
        kembali("edit.php?id=$id", "error", "Semua data wajib diisi.");
    }

    if (!is_numeric($harga) || $harga < 0) {
        kembali("edit.php?id=$id", "error", "Harga harus berupa angka yang valid.");
    }

    if (!is_numeric($stok) || $stok < 0) {
        kembali("edit.php?id=$id", "error", "Stok harus berupa angka yang valid.");
    }

    $old_query = mysqli_query($conn, "SELECT gambar FROM produk WHERE id = $id");
    $old_data = mysqli_fetch_assoc($old_query);

    if (!$old_data) {
        kembali("produk.php", "error", "Produk tidak ditemukan.");
    }

    $gambar = $old_data['gambar'];

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] !== UPLOAD_ERR_NO_FILE) {
        $new_gambar = uploadGambar('gambar', '../uploads/produk/');

        if ($new_gambar === false) {
            kembali("edit.php?id=$id", "error", "Gambar harus JPG, JPEG, PNG, atau WEBP dan maksimal 2 MB.");
        }

        if ($new_gambar !== null) {
            $gambar = $new_gambar;

            if ($old_data['gambar'] && file_exists("../uploads/produk/" . $old_data['gambar'])) {
                unlink("../uploads/produk/" . $old_data['gambar']);
            }
        }
    }

    $harga = (float)$harga;
    $stok = (int)$stok;

    $stmt = mysqli_prepare(
        $conn,
        "UPDATE produk
         SET nama = ?, kategori = ?, deskripsi = ?, harga = ?, stok = ?, gambar = ?
         WHERE id = ?"
    );
    mysqli_stmt_bind_param($stmt, "sssdisi", $nama, $kategori, $deskripsi, $harga, $stok, $gambar, $id);

    if (mysqli_stmt_execute($stmt)) {
        kembali("produk.php", "success", "Produk berhasil diperbarui.");
    }

    kembali("edit.php?id=$id", "error", "Produk gagal diperbarui.");
}

kembali("produk.php", "error", "Aksi tidak dikenali.");
