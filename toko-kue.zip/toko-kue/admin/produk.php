<?php
session_start();
require_once "../includes/auth.php";
require_once "../config/database.php";

$keyword = $_GET['keyword'] ?? '';
$kategori = $_GET['kategori'] ?? '';
$where = [];

if ($keyword != '') {
    $keyword_safe = mysqli_real_escape_string($conn, $keyword);
    $where[] = "nama LIKE '%$keyword_safe%'";
}

if ($kategori != '') {
    $kategori_safe = mysqli_real_escape_string($conn, $kategori);
    $where[] = "kategori = '$kategori_safe'";
}

$where_sql = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";

$per_page = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $per_page;

$count_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM produk $where_sql"
);
$count_data = mysqli_fetch_assoc($count_query);
$total_data = $count_data['total'];
$total_page = ceil($total_data / $per_page);

$query = mysqli_query(
    $conn,
    "SELECT * FROM produk
     $where_sql
     ORDER BY id DESC
     LIMIT $per_page OFFSET $offset"
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk — Admin Sweet Cake</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="admin-shell">
<aside class="admin-side">
    <div class="admin-brand">
        <strong>Sweet Cake</strong>
        <span>Admin Panel</span>
    </div>
    <nav class="admin-menu">
        <a class="" href="index.php">⌂ Dashboard</a>
        <a class="active" href="produk.php">▣ Produk</a>
        <a href="../index.php">↗ Website</a>
        <a href="logout.php">↪ Logout</a>
    </nav>
</aside>
    <main class="admin-content">
        <div class="admin-inner">
            <div class="admin-top">
                <div>
                    <h1>Kelola Produk</h1>
                    <p class="muted">Atur katalog produk Sweet Cake.</p>
                </div>
                <a href="tambah.php" class="btn">＋ Tambah Produk</a>
            </div>

            <?php include "../includes/flash.php"; ?>

            <div class="card">
                <form method="GET" class="form-grid">
                    <div>
                        <label for="keyword">Cari Produk</label>
                        <input id="keyword" type="text" name="keyword"
                               placeholder="Nama produk..."
                               value="<?= htmlspecialchars($keyword); ?>">
                    </div>
                    <div>
                        <label for="kategori">Kategori</label>
                        <select id="kategori" name="kategori">
                            <option value="">Semua Kategori</option>
                            <option value="Cake" <?= $kategori == 'Cake' ? 'selected' : ''; ?>>Cake</option>
                            <option value="Brownies" <?= $kategori == 'Brownies' ? 'selected' : ''; ?>>Brownies</option>
                            <option value="Donat" <?= $kategori == 'Donat' ? 'selected' : ''; ?>>Donat</option>
                        </select>
                    </div>
                    <div class="form-full" style="display:flex;gap:8px;flex-wrap:wrap;">
                        <button type="submit" class="btn">Terapkan Filter</button>
                        <a href="produk.php" class="btn btn-light">Reset</a>
                    </div>
                </form>
            </div>

            <div class="card">
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Gambar</th>
                                <th>Nama</th>
                                <th>Kategori</th>
                                <th>Harga</th>
                                <th>Stok</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no = $offset + 1; ?>
                        <?php while ($row = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td>
                                    <?php if ($row['gambar']): ?>
                                        <img class="table-thumb"
                                             src="../uploads/produk/<?= htmlspecialchars($row['gambar']); ?>"
                                             alt="">
                                    <?php else: ?>
                                        <span class="muted">Tidak ada</span>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?= htmlspecialchars($row['nama']); ?></strong></td>
                                <td><?= htmlspecialchars($row['kategori']); ?></td>
                                <td>Rp <?= number_format($row['harga'],0,',','.'); ?></td>
                                <td><?= $row['stok']; ?></td>
                                <td>
                                    <div class="actions">
                                        <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-small">Edit</a>
                                        <a href="hapus.php?id=<?= $row['id']; ?>"
                                           class="btn btn-danger btn-small"
                                           onclick="return confirm('Yakin ingin menghapus produk?')">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="pagination">
                <?php for ($i = 1; $i <= $total_page; $i++): ?>
                    <a href="?page=<?= $i; ?>&keyword=<?= urlencode($keyword); ?>&kategori=<?= urlencode($kategori); ?>">
                        <?= $i; ?>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    </main>
</div>
</body>
</html>
