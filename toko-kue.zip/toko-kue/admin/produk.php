<?php
require_once "../includes/auth.php";
require_once "../config/database.php";

$keyword = trim($_GET['keyword'] ?? '');
$kategori = trim($_GET['kategori'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 8;
$offset = ($page - 1) * $limit;

$where = [];
if ($keyword !== '') {
    $safe = mysqli_real_escape_string($conn, $keyword);
    $where[] = "(nama LIKE '%$safe%' OR deskripsi LIKE '%$safe%')";
}
if ($kategori !== '') {
    $safe_kategori = mysqli_real_escape_string($conn, $kategori);
    $where[] = "kategori = '$safe_kategori'";
}
$where_sql = count($where) ? "WHERE " . implode(" AND ", $where) : "";

$total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM produk $where_sql"))['total'];
$total_page = max(1, ceil($total / $limit));

$query = mysqli_query(
    $conn,
    "SELECT * FROM produk $where_sql ORDER BY id DESC LIMIT $offset, $limit"
);

$kategori_query = mysqli_query($conn, "SELECT DISTINCT kategori FROM produk ORDER BY kategori ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk — Admin Hearts to Hearts</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-side">
        <div class="admin-brand">
            <div class="admin-logo">♥</div>
            <div><strong>Hearts to Hearts</strong><span>Admin Studio</span></div>
        </div>
        <div class="admin-label">MENU UTAMA</div>
        <nav class="admin-menu">
            <a href="index.php"><span>⌂</span> Dashboard</a>
            <a class="active" href="produk.php"><span>▣</span> Produk</a>
            <a href="../index.php"><span>↗</span> Lihat Website</a>
        </nav>
        <div class="sidebar-bottom">
            <div class="admin-mini-card"><span class="mini-heart">♥</span><div><small>Signed in as</small><strong><?= htmlspecialchars($_SESSION['admin_nama']); ?></strong></div></div>
            <a href="logout.php" class="logout-link">↪ Keluar dari akun</a>
        </div>
    </aside>

    <main class="admin-content">
        <div class="admin-inner">
            <header class="admin-top">
                <div><span class="section-kicker">CATALOG MANAGEMENT</span><h1>Produk</h1><p class="muted">Atur semua produk yang tampil di website.</p></div>
                <a href="tambah.php" class="btn">+ Tambah Produk</a>
            </header>

            <?php require "../includes/flash.php"; ?>

            <div class="card filter-card">
                <form method="GET" class="filter-grid">
                    <div class="search-input">
                        <span>⌕</span>
                        <input type="text" name="keyword" placeholder="Cari produk..." value="<?= htmlspecialchars($keyword); ?>">
                    </div>
                    <select name="kategori">
                        <option value="">Semua Kategori</option>
                        <?php while ($kat = mysqli_fetch_assoc($kategori_query)): ?>
                            <option value="<?= htmlspecialchars($kat['kategori']); ?>" <?= $kategori === $kat['kategori'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($kat['kategori']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                    <button type="submit" class="btn">Filter</button>
                    <a href="produk.php" class="btn btn-light">Reset</a>
                </form>
            </div>

            <div class="card admin-table-card">
                <div class="card-heading">
                    <div><span class="section-kicker">CATALOG</span><h2>Daftar Produk <small>(<?= $total; ?> item)</small></h2></div>
                </div>
                <div class="table-wrap">
                    <table class="admin-products-table">
                        <thead><tr><th>No</th><th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr></thead>
                        <tbody>
                        <?php if (mysqli_num_rows($query) === 0): ?>
                            <tr><td colspan="6" class="table-empty">Belum ada data produk yang sesuai.</td></tr>
                        <?php endif; ?>

                        <?php $no = $offset + 1; ?>
                        <?php while ($row = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td>
                                    <div class="table-product">
                                        <?php if ($row['gambar']): ?>
                                            <img src="../uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" alt="">
                                        <?php else: ?>
                                            <span class="table-heart">♡</span>
                                        <?php endif; ?>
                                        <div><strong><?= htmlspecialchars($row['nama']); ?></strong><small><?= htmlspecialchars($row['deskripsi']); ?></small></div>
                                    </div>
                                </td>
                                <td><span class="category-pill"><?= htmlspecialchars($row['kategori']); ?></span></td>
                                <td><strong>Rp <?= number_format($row['harga'],0,',','.'); ?></strong></td>
                                <td><span class="<?= $row['stok'] <= 5 ? 'stock-low' : 'stock-ok'; ?>"><?= $row['stok']; ?> pcs</span></td>
                                <td>
                                    <div class="actions">
                                        <a href="edit.php?id=<?= $row['id']; ?>" class="action-btn edit">Edit</a>
                                        <a href="hapus.php?id=<?= $row['id']; ?>" class="action-btn delete" onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if ($total_page > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $total_page; $i++): ?>
                        <a class="<?= $page == $i ? 'active' : ''; ?>" href="?page=<?= $i; ?>&keyword=<?= urlencode($keyword); ?>&kategori=<?= urlencode($kategori); ?>"><?= $i; ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
