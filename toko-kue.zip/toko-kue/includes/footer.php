<footer class="site-footer">
    <div class="container">
        <span>Hearts to Hearts</span>
        <span>Made with love ♡</span>
    </div>
</footer>
