<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang — Hearts to Hearts</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php"><span class="brand-mark">♥</span><span>Hearts <i>to</i> Hearts</span></a>
        <div class="nav-links">
            <a href="index.php">Beranda</a>
            <a href="produk.php">Koleksi</a>
            <a class="active" href="tentang.php">Tentang</a>
            <a href="auth/login.php" class="nav-admin">Admin <span>→</span></a>
        </div>
    </div>
</nav>

<main class="section">
    <div class="container">
        <div class="about-layout">
            <div class="about-intro">
                <span class="eyebrow">OUR STORY</span>
                <h1 class="page-title">A little place<br><em>made with heart.</em></h1>
                <p>
                    Hearts to Hearts adalah konsep toko kue yang membawa suasana hangat,
                    sederhana, dan personal. Kami percaya bahwa makanan manis bukan hanya
                    tentang rasa, tetapi juga tentang cerita yang menyertainya.
                </p>
                <p>
                    Website ini dibuat untuk membantu menampilkan katalog produk secara
                    digital sekaligus menyediakan sistem pengelolaan produk untuk admin.
                </p>
            </div>

            <div class="about-card">
                <div class="about-big-heart">♥</div>
                <span>HEARTS TO HEARTS</span>
                <strong>Sweet things,<br>shared feelings.</strong>
                <small>♡ Since 2026</small>
            </div>
        </div>

        <div class="values-grid">
            <div class="value-card"><span>01</span><strong>Care</strong><p>Setiap produk diperhatikan dari data, tampilan, sampai informasi yang diberikan.</p></div>
            <div class="value-card"><span>02</span><strong>Simple</strong><p>Informasi dibuat sederhana agar pelanggan mudah menemukan produk yang dicari.</p></div>
            <div class="value-card"><span>03</span><strong>Digital</strong><p>Katalog online membantu produk lebih mudah dikenalkan dan dikelola.</p></div>
        </div>
    </div>
</main>

<footer class="site-footer">
    <div class="container"><span>Hearts to Hearts</span><span>Made with love ♡</span></div>
</footer>

</body>
</html>
