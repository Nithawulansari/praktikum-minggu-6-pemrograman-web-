<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami — Sweet Cake</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="site-nav">
    <div class="container nav-inner">
        <a class="brand" href="index.php">
            <span class="brand-mark">♥</span>
            <span>Sweet Cake</span>
        </a>
        <div class="nav-links">
            <a href="index.php">Beranda</a>
            <a href="produk.php">Produk</a>
            <a href="tentang.php">Tentang Kami</a>
        </div>
    </div>
</nav>

<main class="section">
    <div class="container">
        <div class="card">
            <span class="eyebrow">About Sweet Cake</span>
            <h1 class="page-title" style="margin-top:16px;">Tentang Sweet Cake</h1>
            <p class="product-desc">
                Sweet Cake adalah UMKM yang bergerak dalam bidang produksi dan penjualan berbagai macam kue.
            </p>
            <p class="product-desc">
                Kami menyediakan produk kue untuk kebutuhan keluarga, acara ulang tahun,
                pernikahan, maupun berbagai acara lainnya.
            </p>

            <div class="info-list">
                <div class="info-box">
                    <small>WhatsApp</small>
                    <strong>08xxxxxxxxxx</strong>
                </div>
                <div class="info-box">
                    <small>Instagram</small>
                    <strong>@sweetcake</strong>
                </div>
            </div>
        </div>
    </div>
</main>

<footer class="site-footer">
    <div class="container">Sweet Cake · Kue manis untuk momen istimewa ♡</div>
</footer>

</body>
</html>
